/**
 ******************************************************************************
 * @file           : main.c
 * @author         : Muhammed Cemal Eryigit
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2022 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
#include "stm32h7xx.h"
//SystemCoreClock = 64 MHz
unsigned char WAdr, RAdr;
char RxBuf[128];
int j = 0;

void FLASH_UnLock(void) //Bitti
{
	/*
	 * FLASH_CR kaydının kilidini açmak ve programlama/silme işlemlerini sağlamak için FLASH->KEYR
	 * kaydedicisine KEY1 ve KEY2 değerleri sırasıyla yazılmalıdır.
	 */
	while ((FLASH->SR1 & 0x00000001) != 0 );	// Flash Bank1 belleğin meşgul olmamasını bekle

	if(FLASH->CR1 & 0x00000001)				// Flaş Bank1'in kilidinin açık olup olmadığını kontrol et  LOCK1 registeri kontrol edilir
	{
		FLASH->KEYR1 = 0x45670123;
		FLASH->KEYR1 = 0xCDEF89AB;
	}
}
void Boodloader_Read_Data() //Yazılacak
{

}

void Boodloader_Send_Data() //Yazılacak
{

}


void FLASH_Opt_UnLock(void) //Bitti
{
	 // FLASH Optional Byte kilidini açmak ve programlama/silme işlemlerini sağlamak için FLASH->OPTKEYR
	 //kaydedicisine KEY1 ve KEY2 değerleri sırasıyla yazılmalıdır.
	while ((FLASH->OPTSR_CUR & 0x00000001) != 0 );	// Flash OPT belleğin meşgul olmamasını bekle FLASH_OPTSR_CUR

	if(FLASH->OPTCR & 0x00000001)				// Flaş OPT'nin kilidinin açık olup olmadığını kontrol et
	{
		FLASH->OPTKEYR = 0x08192A3B;
		FLASH->OPTKEYR = 0x4C5D6E7F;
	}
}
void FLASH_Opt_Locker(void) // opt lock 1 yazılacak tekrar bak
{
	 //FLASH_Opt_CR kaydının kilitlemek ve programlama/silme işlemlerini durdurmak için FLASH->CR
	 // kaydedicisinin LOCK bitine 1 yazılmalıdır.
	FLASH->OPTCR |= 0x80000000;
}
void FLASH_Locker(void) //Bitti
{
	 // FLASH_CR kaydının kilitlemek ve programlama/silme işlemlerini durdurmak için FLASH->CR
	 //kaydedicisinin LOCK bitine 1 yazılmalıdır.
	FLASH->CR1 |= 0x80000000;
}
/*
void FLASH_Erase(void) //Düzenlenecek
{
	/*
	 * Silmek demek Flaş'ı 0x0000 yapmak demek değil 0xFFFF yapmak demektir.
	 * Silme işlemi için:
	 * 	1- Status registerindaki busy(BSY) bitini kontrol ederek Flash belleği işlemlerinin devam etmediğini doğrula.
	 * 	2- CR kaydedicisindeki SER bitini ayarla ve silmek istediğin sectoru ana bellek bloğundaki SNB den belirle
	 * 	3- CR kaydedicisindeki STRT bitini ayarla
	 * 	4- Status registerindaki busy(BSY) bitinin temizlenmesini bekle

	// Bayrakları temizle
	FLASH->SR1 |= 0x00000001;				// End of Operation flag clear
	FLASH->SR1 |= 0x00000040;				// Programming Parallelism error flag clear
	FLASH->SR1 |= 0x00000010;				// Write protected error flag clear

	while ((FLASH->SR1 & 0x00000001) != 0 );	// Meşguliyet bitene kadar bekle
	FLASH->CR1 |= 0x00000004;				// sektör silme bitini ayarla (SER1)
	FLASH->CR1 |= 11 << 3;					// Sektör 11 silinecek sektör olarak seçildi
	FLASH->CR1 |= 1 << 16;					// STRT biti 1 olarak ayarlandı
	while(FLASH->SR1 & 0x00010000);			// İşlemler bitene kadar bekle

	if((FLASH->SR1 & 0x00000001) != 0)		// İşlem sonu biti ayarlandı ise
	{
	    FLASH->SR1 |= 0x00000001;			// İşlem başarılı oldu, işlem sonu bağrağı temizle
	}
	FLASH->CR1 &= ~0x00000002; 				// CR register'ı PER biti başlangıçtaki duruma ayarla
}
void FLASH_Write(uint32_t address, uint32_t data) //Düzenlenecek
{
	/*
	 * Yazma işlemi için:
	 * 	1- Status register'ındaki busy(BSY) bitini kontrol ederek Flash belleği işlmelerinin devam etmediğini doğrula
	 * 	2- CR kaydedicisindeki Programming Enable(PG) bitini ayarla
	 * 	3- Veri yazma işlemini istenilen adrese yap (ana hafıza bloğu veya OTP içerisinde)
	 * 		- x8 paralelliği durumunda bayt erişimi
	 * 		- x16 paralellik durumunda yarım kelimelik erişim
	 * 		- x32 paralellik durumunda kelime erişimi
	 * 		- x64 paralellik durumunda çift kelime erişimi
	 * 	4- Status register'ındaki busy(BSY) bitinin temizlenmesini bekle

	while(FLASH->SR1 & 0x00010000);		// Meşguliyet bitene kadar bekle
	FLASH->CR1 |= 0x00000001;			// PG biti ayarlandı, Programmin modda
	FLASH->CR1 |= 2 << 8;				// Program size 32
	*(__IO uint32_t*)address = data;	// İstenilen adrese istenilen veri yazılıyor.
	while(FLASH->SR1 & 0x00010000);		// İşlemler bitene kadar bekle

	if((FLASH->SR1 & 0x00000001) != 0)	// İşlem sonu biti ayarlandı ise
	{
	     FLASH->SR1 |= 0x00000001;		// İşlem başarılı oldu, işlem sonu bağrağı temizle
	}

	FLASH->CR1 &= ~0x00000001;			// CR register'ı PG biti başlangıçtaki duruma ayarla
}
uint32_t FLASH_Read(uint32_t address) //Düzenlenecek
{
	uint32_t myFlashData;

	myFlashData = (*(uint32_t*)address);

	return myFlashData;
}
*/
void Delay(uint32_t time) //Bitti
{
	while(time--);

}


void GPIO_Config() //Usart için config edildi //Bitti
{

	RCC->AHB4ENR  |= 0x8;		// GPIOD Clock Enable

	GPIOD->MODER  &= 0xAFFFF;		// AF PD8 AND PD9
	GPIOD->AFR[1] |= (7 << 0) | (7 << 4);		// PD8 & PD9 AF7 (USART3)
}

void USART_Config(uint32_t baud) //Bitti
{
	RCC->APB1LENR |= 0x40000;

	USART3->BRR = 0x22c;		// BaudRate
	USART3->CR1 |= 1 << 2;		// Rx enable PD9
	USART3->CR1 |= 1 << 3;		// Tx enable //PD8
	USART3->CR1 |= 0 << 10;		// Parity control disable
	USART3->CR1 |= 0 << 12;		// Word length 8bit
	USART3->CR2 |= 0 << 12;		// Stop bit 1

	USART3->CR1 |= 1 << 0;		// Usart enable


	NVIC_SetPriority(USART3_IRQn , 1);
	NVIC_EnableIRQ(USART3_IRQn);
}

/*
char DataReady()
{
	return (WAdr-RAdr);
}

char ReadChar()
{
	char Dat;
	Dat = RxBuf[RAdr];
	RAdr=(RAdr+1)&0x7F;
	return(Dat);
}
*/


void printChar(char c){
	USART3->TDR = (uint16_t) c;
	while(!(USART3->ISR & (1 << 6))); // 6.bit transmission complete
}

void SendTxt(char *Adr)
{
	while(*Adr)
	{
		printChar(*Adr);
		Adr++;
	}
}


void USART3_IRQHandler(void){
	uint8_t data = (uint8_t)USART3->RDR;
    //RXNE is automatically cleared when read
	printChar(data);
}
int main(void)
{
	GPIO_Config();
	USART_Config(115200);
	//FLASH_Opt_UnLock();
	//FLASH->BOOT_PRG &=  0x1FF00000;
	//FLASH_Opt_Locker();

	 while(1)
	    {
		 SendTxt("Hello \n");

	    }


	 return 0;
}
